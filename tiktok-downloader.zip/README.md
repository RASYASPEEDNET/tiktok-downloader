# 🎥 TikTok Downloader (PHP)

Downloader sederhana untuk video TikTok:
- ✅ Download tanpa watermark
- ✅ Download dengan watermark
- ✅ Download audio (MP3)

## 🚀 Cara Jalankan di Localhost
```bash
git clone https://github.com/USERNAME/tiktok-downloader.git
cd tiktok-downloader
php -S 0.0.0.0:8080 -t .
```
Lalu buka browser:
```
http://localhost:8080/index.php
```

## 🌍 Deploy Gratis
- Upload `index.php` ke hosting (contoh: 000webhost, InfinityFree).
- Atau deploy ke Heroku / Render.
